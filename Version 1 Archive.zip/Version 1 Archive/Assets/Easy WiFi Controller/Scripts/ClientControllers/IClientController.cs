﻿namespace EasyWiFi.ClientControls
{

    interface IClientController
    {
        void mapInputToDataStream();
    }

}
