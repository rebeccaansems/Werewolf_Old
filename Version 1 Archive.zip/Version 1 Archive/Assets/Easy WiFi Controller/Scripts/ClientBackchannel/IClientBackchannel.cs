﻿namespace EasyWiFi.ClientBackchannels
{
    interface IClientBackchannel
    {
        void mapDataStructureToMethod();
    }

}
