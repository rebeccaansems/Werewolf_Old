﻿namespace EasyWiFi.ServerBackchannels
{

    interface IServerBackchannel
    {
        void mapPropertyToDataStream(int index);
    }
}
